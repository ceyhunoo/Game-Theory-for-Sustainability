from tkinter import *
from PIL import Image, ImageTk
from tkinter.filedialog import askopenfile
from math import ceil 
from time import sleep
from tkinter.font import Font
import openpyxl

traktor_each = 1/100
capamakinesi_each = 1/80
gubre_each = 1
ilac_each = 1/2
ottemizleme_each = 1/40

# Envanter fiyatlarını yapılan araştırmalar sonucunda ortaya çıkan ortalama değer üzerinden hesaplanıyor.
fiyat_traktor = 250000 # 1 tane
fiyat_capamakinesi = 5000 # 1 tane
fiyat_gubre = 5000 # 1 ton
fiyat_ilac = 85 # litre
fiyat_ottemizleme = 1200 #1 tane

root = Tk()
root.title('Veri Hesaplama Aracı')
root.geometry('600x700')

myfont = Font(
    family='Bahnschrift Light Condensed',
    size=16)

canvas = Canvas(root, width=600, height=700)
canvas.grid(columnspan=4, rowspan=7)


# TÜBİTAK Logo
logo2 = Image.open('logo2.jpg')
logo2 = logo2.resize((300,200), Image.ANTIALIAS)
logo2 = ImageTk.PhotoImage(logo2)
logo2_label = Label(image=logo2)
logo2_label.image = logo2
logo2_label.grid(column=1, row=0, columnspan=2)

# Instruction
instructions_label = Label(root, text='Lütfen eklemek istediğiniz excel dosyasını seçiniz.', font=myfont)
instructions_label.grid(columnspan=4, row=2, column=0)

def open_file():
    global instructions_label, browse_button, traktor_amount, capamakinesi_amount, gubre_amount, ilac_amount, ottemizleme_amount, toplam_fiyat, farmers, terrains, products
    farmers = []
    terrains = []
    products = []
    browse_text.set('yükleniyor...')
    sleep(0.5)
    file = askopenfile(parent=root, mode='rb', title='Dosya seçiniz', filetype=[('Excel file', '*.xlsx')])
    if file:
        ws = openpyxl.load_workbook(str(file.name)).active
        x = 2
        while ws[f'A{x}'].value != None:
            farmers.append(ws[f'A{x}'].value)
            x += 1
        x = 2
        while ws[f'B{x}'].value != None:
            terrains.append(ws[f'B{x}'].value)
            x += 1
        x = 2
        while ws[f'C{x}'].value != None:
            products.append(ws[f'C{x}'].value)
            x += 1

        total_terrain = 0
        for x in terrains:
            total_terrain += x


        traktor_amount = ceil(total_terrain*traktor_each)
        capamakinesi_amount = ceil(total_terrain*capamakinesi_each)
        gubre_amount = ceil(total_terrain*gubre_each)
        ilac_amount = ceil(total_terrain*ilac_each)
        ottemizleme_amount = ceil(total_terrain*ottemizleme_each)

        toplam_fiyat = (traktor_amount * fiyat_traktor) + (capamakinesi_amount * fiyat_capamakinesi) + (gubre_amount * fiyat_gubre)
        toplam_fiyat += (ilac_amount * fiyat_ilac) + (ottemizleme_amount * fiyat_ottemizleme)

        root.destroy()
        root.quit()

        return farmers, terrains, products, traktor_amount, capamakinesi_amount, gubre_amount, ilac_amount, ottemizleme_amount, toplam_fiyat
    else:
        browse_text.set('Dosya Seçiniz')

browse_text = StringVar()
browse_button = Button(root, textvariable=browse_text, command= lambda:open_file(),bg='#808080', fg='white', height=2, width=15, font=myfont)
browse_text.set('Dosya Seçiniz')
browse_button.grid(column=1, row=3, columnspan=2)

root.mainloop()

root2 = Tk()
root2.title('Veri Alım Aracı')

def con_button_command():
    root2.destroy()
    root2.quit()

def generate_button_command():
    generate_button.destroy()
    sleep(1)
    y=0
    gtext = ""
    l1 = Label(root2, text= "\tÇiftçi\t\t\tArazi(Dönüm)\tÜrün")
    l1.pack()
    for x in farmers:
        y += 1
        gtext += f"{y}. çiftçi: {farmers[y-1]}\t\t{terrains[y-1]}\t\t{products[y-1]}\n"
    generate_label = Label(root2, text= f"{gtext}")
    generate_label.pack()
    con_button = Button(root2, text='Devam', command=lambda: con_button_command())
    con_button.pack()
    
generate_button = Button(root2, text='Oluştur', command= generate_button_command)
generate_button.pack()

root2.mainloop()

root = Tk()

root.title("Veri Sonuçları")

traktor_label1 = Label(root, text="Gereken traktör miktarı: ",font=myfont,anchor='w', justify=LEFT)
traktor_label2 = Label(root, text=f"{traktor_amount} adet",font=myfont,anchor='e')

traktor_label1.grid(row=0, column=0)
traktor_label2.grid(row=0, column=1)

capamakinesi_label1 = Label(root, text="Çapa makinesi miktarı: ",font=myfont,anchor='w')
capamakinesi_label2 = Label(root, text=f"{capamakinesi_amount} adet",font=myfont,anchor='e')

capamakinesi_label1.grid(row=1, column=0)
capamakinesi_label2.grid(row=1, column=1)

gubre_label1 = Label(root, text="Gereken gübre miktarı: ",font=myfont,anchor='w')
gubre_label2 = Label(root, text=f"{gubre_amount} ton",font=myfont,anchor='e')

gubre_label1.grid(row=2, column=0)
gubre_label2.grid(row=2, column=1)

ilac_label1 = Label(root, text="Gereken zararlılarla mücadele ilacı miktarı: ",font=myfont,anchor='w')
ilac_label2 = Label(root, text=f"{ilac_amount} litre",font=myfont,anchor='e')

ilac_label1.grid(row=3, column=0)
ilac_label2.grid(row=3, column=1)

ottemizleme_label1 = Label(root, text="Gereken ot temizleme makinesi miktarı: ",font=myfont,anchor='w')
ottemizleme_label2 = Label(root, text=f"{ottemizleme_amount} adet",font=myfont,anchor='e')

ottemizleme_label1.grid(row=4, column=0)
ottemizleme_label2.grid(row=4, column=1)

toplam_fiyat_label1 = Label(root, text="Toplam fiyat: ",font=myfont,anchor='w')
toplam_fiyat_label2 = Label(root, text=f"{toplam_fiyat}TL",font=myfont,anchor='e')

toplam_fiyat_label1.grid(row=5, column=0)
toplam_fiyat_label2.grid(row=5, column=1)

root.mainloop()